<?php
$app_name = "phpJobScheduler";
$phpJobScheduler_version = "3.9";

/* added no cache header * if sub directory in a web server with cache managment */

header("Cache-Control: no-store, no-cache, must-revalidate"); // HTTP/1.1
header("Cache-Control: post-check=0, pre-check=0", false);
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Date in the past
header("Pragma: no-cache"); // HTTP/1.0
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");

include_once("functions.php");
update_db(); // check database is up-to-date, if not add required tables
include("header.html");
if (isset($_GET['add'])) include("add-modify.html");
else include("main.html");
include("footer.html");
?>