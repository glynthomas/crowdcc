<?php
// ---------------------------------------------------------
 $app_name = "phpJobScheduler";
 $phpJobScheduler_version = "3.9";
// ---------------------------------------------------------

define('DBHOST', 'localhost'); // database host address - localhost is usually fine

define('DBNAME', 'crowdcc_shed');      // database name - must already exist
define('DBUSER', 'root');      // database username - must already exist
define('DBPASS', 'beta');      // database password for above username

define('DEBUG', false);         // set to false production mode * debug messages are suppressed * true development mode * debug messages are shown * check php error log! ( testing )