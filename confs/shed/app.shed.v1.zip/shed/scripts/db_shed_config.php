<?php

/**
*
* db_config.php
* MySQL connection parameters for crowdcc database server
*
**/

  define('__DB_ROOT__', dirname(dirname(__FILE__)));
  
  define('DB_CONFIG_DIR', __DB_ROOT__ .'/scripts');
  // Server path for scripts within the framework to reference each other
  define('CODE_DIR', __DB_ROOT__ .'/scripts');
 
  define("HOST", "localhost");                     // The host you want to connect to.
  define("USER", "root");                          // The database username
  define("PASSWORD", "beta");                      // The database password. 
 
  $mysqli_sess = new mysqli(HOST, USER, PASSWORD, 'crowdcc_sessions');
  $mysqli_sign = new mysqli(HOST, USER, PASSWORD, 'crowdcc_signin');

  mysqli_query($mysqli_sess, 'SET NAMES "utf8"');
  mysqli_query($mysqli_sess, 'SET CHARACTER SET "utf8"');
  mysqli_query($mysqli_sess, 'SET character_set_results = "utf8",' .
  'character_set_client = "utf8", character_set_connection = "utf8",' .
  'character_set_database = "utf8", character_set_server = "utf8"');

  mysqli_query($mysqli_sign, 'SET NAMES "utf8"');
  mysqli_query($mysqli_sign, 'SET CHARACTER SET "utf8"');
  mysqli_query($mysqli_sign, 'SET character_set_results = "utf8",' .
  'character_set_client = "utf8", character_set_connection = "utf8",' .
  'character_set_database = "utf8", character_set_server = "utf8"');

  date_default_timezone_set("Europe/London");
  $timezone = 'Europe/London';
  $now = time();
  $date = new DateTime(null, new DateTimeZone($timezone));
  $timelocal = date("Y-m-d H:i:s",($date->getTimestamp() + $date->getOffset()));
  /* date_default_timezone_set("UTC"); */

  log_error($timelocal,'connect', mysqli_connect_errno(), $mysqli_sess);
  log_error($timelocal,'connect', mysqli_connect_errno(), $mysqli_sign);

  // If you are connecting via TCP/IP rather than a UNIX socket remember to add the port number as a parameter.

  // Write any errors into a text log include the date, calling script, function called, and query
  // this should be used to report errors on insert or replace db changes only
  function log_error($timelocal, $function, $query, $mysqli) {
   
    mysqli_report(MYSQLI_REPORT_OFF); 				//Turn off irritating default messages

	    switch(true) {

	    	case($mysqli->error):
	    		 $fp = fopen(CODE_DIR . '/error_log.txt','a');
	       		 fwrite($fp, $timelocal . ' | ' . $_SERVER["SCRIPT_NAME"] . ' -> ' . $function . '() failed | ' . htmlspecialchars($query->errno) . ' | ' .  htmlspecialchars($mysqli->error) . "\n");
	       		 fclose($fp);
	    	break;

		  	/*
			    if ($mysqli->error) {

			       // try {   
			       //    throw new Exception("MySQL error $mysqli->error <br> Query:<br> $query", $msqli->errno);   
			       // } catch(Exception $e ) {
			       //    echo "Error No: ".$e->getCode(). " - ". $e->getMessage() . "<br >";
			       //    echo nl2br($e->getTraceAsString());
			       // }
			      
			       $fp = fopen(CODE_DIR . '/error_log.txt','a');
			       fwrite($fp, $timelocal . ' | ' . 
			       $_SERVER["SCRIPT_NAME"] . ' -> ' . $function . 
			       '() failed | ' . htmlspecialchars($query->error) . ' | ' .  htmlspecialchars($mysqli->error) . "\n");
			       fclose($fp);
			*/

	    }
	    
  }
  