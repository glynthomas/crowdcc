<?php       
echo "<H3>correctly run this file:<br><br>". $_SERVER['PHP_SELF'];
?>
