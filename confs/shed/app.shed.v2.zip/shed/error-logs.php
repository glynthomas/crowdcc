<?php
$app_name = "phpJobScheduler";
$phpJobScheduler_version = "3.9";

/* added no cache header * if sub directory in a web server with cache managment */

header("Cache-Control: no-store, no-cache, must-revalidate"); // HTTP/1.1
header("Cache-Control: post-check=0, pre-check=0", false);
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Date in the past
header("Pragma: no-cache"); // HTTP/1.0
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");


//include_once("functions.php");
include_once($_SERVER["DOCUMENT_ROOT"].'/../slib/functions.php');

// include("header.html");
include_once($_SERVER["DOCUMENT_ROOT"].'/../slib/header.html');

// include("error-logs.html");
include_once($_SERVER["DOCUMENT_ROOT"].'/../slib/error-logs.html');

// include("footer.html");
include_once($_SERVER["DOCUMENT_ROOT"].'/../slib/footer.html');


?>